-- Adminer 4.8.1 MySQL 10.4.24-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(100) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `user_id`, `name`, `username`, `email`, `password`, `enabled`, `secret`, `last_login`, `created_at`, `updated_at`) VALUES
(58,	'1111755790',	'alfredo',	'alfredo',	'alexanderson1987@gmail.com',	'$2a$10$oSuGyPU7JxthAAqac4HZKOW9eLjsxFAmJp82lbIXOcC.Z3iNby9tW',	CONV('0', 2, 10) + 0,	'7OSTJ2SH7WPLQZYH',	'2022-05-11 10:53:44',	'2022-05-04 06:36:44',	'2022-05-04 06:36:44'),
(59,	'1111234567',	'dexter',	'dexter',	'dexter1987@gmail.com',	'$2a$10$nLGn.Ktqi9lEp24XbIgm.OSoOAEf/ELcPzu1I15KME3AiksvNEAQW',	CONV('0', 2, 10) + 0,	'4DYIOI7DNSIYROLL',	'2022-05-04 09:51:48',	'2022-05-04 07:57:24',	'2022-05-04 07:57:24'),
(60,	'111123456',	'master',	'master',	'master1987@gmail.com',	'$2a$10$4nERr7ofC1klxVwgtsU3kerzoZdOfsVVWUtrHTTksP3ZJ48c.mBtu',	CONV('0', 2, 10) + 0,	'YZNLJGU4EUHOETJB',	'2022-05-04 15:56:55',	'2022-05-04 15:55:18',	'2022-05-04 15:55:18');

-- 2022-05-13 06:18:56
