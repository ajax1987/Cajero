-- Adminer 4.8.1 MySQL 10.4.24-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `channel`;
CREATE TABLE `channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `channel` (`id`, `name`, `description`) VALUES
(1,	'ATM',	'Automatic Teller Machine'),
(2,	'Web',	'Web site'),
(3,	'App',	'Mobile App'),
(4,	'POS',	'Point of Sales'),
(5,	'Mobile Wallet',	'Mobile Wallet');

DROP TABLE IF EXISTS `choices`;
CREATE TABLE `choices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(40) NOT NULL,
  `poll_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_choices_poll_id` (`poll_id`),
  CONSTRAINT `FK1i68hpih40n447wqx4lpef6ot` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`),
  CONSTRAINT `fk_choices_poll_id` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `devicemetadata`;
CREATE TABLE `devicemetadata` (
  `id` bigint(20) NOT NULL,
  `deviceDetails` varchar(255) DEFAULT NULL,
  `lastLoggedIn` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `hibernate_sequence` (`next_val`) VALUES
(46);

DROP TABLE IF EXISTS `passwordresettoken`;
CREATE TABLE `passwordresettoken` (
  `id` bigint(20) NOT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `token` text DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgdew0adk8xruaoq2rgdsy34w2` (`user_id`),
  CONSTRAINT `FKgdew0adk8xruaoq2rgdsy34w2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `polls`;
CREATE TABLE `polls` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question` varchar(140) NOT NULL,
  `expiration_date_time` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `privilege`;
CREATE TABLE `privilege` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `privilege` (`id`, `name`) VALUES
(1,	'CUSTOMER_READ_PRIVILEGE'),
(2,	'USERSUMMARYDTO_WRITE_PRIVILEGE'),
(3,	'CHANGE_PASSWORD_PRIVILEGE');

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `status` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `product` (`id`, `name`, `description`, `status`) VALUES
(1,	'Savings Account',	'Savings Account',	'ACTIVE'),
(2,	'Checking Account',	'Checking Account',	'ACTIVE');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_roles_name` (`name`),
  UNIQUE KEY `UK_nb4h0p6txrmfc0xbrd1kglp9t` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `name`) VALUES
(1,	'ROLE_ADMIN'),
(2,	'ROLE_USER');

DROP TABLE IF EXISTS `roles_privileges`;
CREATE TABLE `roles_privileges` (
  `role_id` bigint(20) NOT NULL,
  `privilege_id` bigint(20) NOT NULL,
  KEY `role_id` (`role_id`),
  KEY `privilege_id` (`privilege_id`),
  CONSTRAINT `roles_privileges_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `roles_privileges_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `privilege` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `roles_privileges` (`role_id`, `privilege_id`) VALUES
(2,	1),
(2,	2);

DROP TABLE IF EXISTS `transaction_type`;
CREATE TABLE `transaction_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `transaction_type` (`id`, `description`) VALUES
(1,	'Withdrawal'),
(2,	'Deposit'),
(3,	'POS'),
(4,	'Online'),
(5,	'Transfer');

DROP TABLE IF EXISTS `transaction_user_product`;
CREATE TABLE `transaction_user_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_product_id` int(11) NOT NULL,
  `channel_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `transaction_number` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel_id` (`channel_id`),
  KEY `type` (`type`),
  KEY `user_product_id` (`user_product_id`),
  CONSTRAINT `transaction_user_product_ibfk_12` FOREIGN KEY (`channel_id`) REFERENCES `channel` (`id`),
  CONSTRAINT `transaction_user_product_ibfk_13` FOREIGN KEY (`user_product_id`) REFERENCES `user_product` (`id`),
  CONSTRAINT `transaction_user_product_ibfk_14` FOREIGN KEY (`type`) REFERENCES `transaction_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `transaction_user_product` (`id`, `user_product_id`, `channel_id`, `amount`, `status`, `type`, `transaction_number`, `created_at`, `updated_at`) VALUES
(123,	11,	2,	50000,	'APPROVED',	5,	225973965,	'2022-05-04 08:04:37',	'2022-05-04 08:04:37'),
(124,	11,	2,	50000,	'APPROVED',	5,	871033719,	'2022-05-04 08:11:27',	'2022-05-04 08:11:27'),
(125,	11,	2,	50000,	'APPROVED',	5,	796696006,	'2022-05-04 08:22:16',	'2022-05-04 08:22:16'),
(126,	13,	2,	50000,	'APPROVED',	5,	224795933,	'2022-05-04 08:23:53',	'2022-05-04 08:23:53'),
(127,	13,	2,	50000,	'APPROVED',	1,	590667235,	'2022-05-04 08:33:13',	'2022-05-04 08:33:13'),
(128,	13,	2,	50000,	'APPROVED',	1,	358237126,	'2022-05-04 08:36:10',	'2022-05-04 08:36:10'),
(129,	13,	2,	50000,	'APPROVED',	2,	996078046,	'2022-05-04 08:37:03',	'2022-05-04 08:37:03'),
(130,	13,	2,	50000,	'APPROVED',	5,	717666433,	'2022-05-04 08:52:59',	'2022-05-04 08:52:59'),
(131,	13,	2,	50000,	'APPROVED',	5,	8820867,	'2022-05-04 08:55:47',	'2022-05-04 08:55:47'),
(132,	13,	2,	50000,	'APPROVED',	5,	656114007,	'2022-05-04 09:00:11',	'2022-05-04 09:00:11'),
(133,	13,	2,	50000,	'APPROVED',	5,	613552704,	'2022-05-04 09:08:38',	'2022-05-04 09:08:38'),
(134,	13,	2,	50000,	'APPROVED',	5,	635165090,	'2022-05-04 09:09:47',	'2022-05-04 09:09:47'),
(135,	13,	2,	50000,	'APPROVED',	1,	516221728,	'2022-05-04 09:17:26',	'2022-05-04 09:17:26'),
(136,	13,	2,	50000,	'APPROVED',	2,	383300929,	'2022-05-04 09:19:02',	'2022-05-04 09:19:02'),
(137,	13,	2,	50000,	'APPROVED',	2,	589617425,	'2022-05-04 09:19:16',	'2022-05-04 09:19:16'),
(138,	12,	2,	50000,	'APPROVED',	1,	68010452,	'2022-05-04 09:21:39',	'2022-05-04 09:21:39'),
(139,	11,	2,	50000,	'APPROVED',	1,	367425887,	'2022-05-04 09:22:04',	'2022-05-04 09:22:04'),
(140,	12,	2,	50000,	'APPROVED',	1,	155423568,	'2022-05-04 09:22:17',	'2022-05-04 09:22:17'),
(141,	12,	2,	50000,	'APPROVED',	1,	660248021,	'2022-05-04 09:22:29',	'2022-05-04 09:22:29'),
(142,	12,	2,	50000,	'APPROVED',	1,	901586449,	'2022-05-04 09:22:45',	'2022-05-04 09:22:45'),
(143,	12,	2,	50000,	'APPROVED',	2,	91612514,	'2022-05-04 09:23:08',	'2022-05-04 09:23:08'),
(144,	12,	2,	50000,	'APPROVED',	2,	973433871,	'2022-05-04 09:23:37',	'2022-05-04 09:23:37'),
(145,	11,	2,	40000,	'APPROVED',	2,	369873108,	'2022-05-04 09:23:43',	'2022-05-04 09:23:43'),
(146,	11,	2,	0,	'APPROVED',	5,	45234173,	'2022-05-04 09:46:37',	'2022-05-04 09:46:37'),
(147,	12,	2,	50000,	'APPROVED',	5,	450993839,	'2022-05-04 15:43:52',	'2022-05-04 15:43:52'),
(148,	12,	2,	50000,	'APPROVED',	5,	467106993,	'2022-05-04 15:48:09',	'2022-05-04 15:48:09'),
(149,	12,	2,	50000,	'APPROVED',	5,	256730389,	'2022-05-04 15:48:47',	'2022-05-04 15:48:47'),
(150,	12,	2,	50000,	'APPROVED',	5,	786355990,	'2022-05-04 15:50:22',	'2022-05-04 15:50:22'),
(151,	11,	2,	50000,	'APPROVED',	5,	866172823,	'2022-05-04 15:53:22',	'2022-05-04 15:53:22'),
(152,	11,	2,	50000,	'APPROVED',	1,	451695380,	'2022-05-04 15:53:56',	'2022-05-04 15:53:56'),
(153,	11,	2,	50000,	'APPROVED',	2,	874426876,	'2022-05-04 15:54:15',	'2022-05-04 15:54:15'),
(154,	14,	2,	50000,	'APPROVED',	5,	53925437,	'2022-05-04 15:57:30',	'2022-05-04 15:57:30'),
(155,	14,	2,	50000,	'APPROVED',	1,	677422926,	'2022-05-04 15:57:50',	'2022-05-04 15:57:50'),
(156,	14,	2,	50000,	'APPROVED',	2,	182538357,	'2022-05-04 15:58:04',	'2022-05-04 15:58:04'),
(157,	12,	2,	50000,	'APPROVED',	5,	822572844,	'2022-05-04 20:55:10',	'2022-05-04 20:55:10');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) CHARACTER SET armscii8 NOT NULL,
  `name` varchar(40) NOT NULL,
  `username` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(100) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `user_id`, `name`, `username`, `email`, `password`, `enabled`, `secret`, `last_login`, `created_at`, `updated_at`) VALUES
(58,	'1111755790',	'alfredo',	'alfredo',	'alexanderson1987@gmail.com',	'$2a$10$oSuGyPU7JxthAAqac4HZKOW9eLjsxFAmJp82lbIXOcC.Z3iNby9tW',	CONV('0', 2, 10) + 0,	'7OSTJ2SH7WPLQZYH',	'2022-05-04 23:29:25',	'2022-05-04 06:36:44',	'2022-05-04 06:36:44'),
(59,	'1111234567',	'dexter',	'dexter',	'dexter1987@gmail.com',	'$2a$10$nLGn.Ktqi9lEp24XbIgm.OSoOAEf/ELcPzu1I15KME3AiksvNEAQW',	CONV('0', 2, 10) + 0,	'4DYIOI7DNSIYROLL',	'2022-05-04 09:51:48',	'2022-05-04 07:57:24',	'2022-05-04 07:57:24'),
(60,	'111123456',	'master',	'master',	'master1987@gmail.com',	'$2a$10$4nERr7ofC1klxVwgtsU3kerzoZdOfsVVWUtrHTTksP3ZJ48c.mBtu',	CONV('0', 2, 10) + 0,	'YZNLJGU4EUHOETJB',	'2022-05-04 15:56:55',	'2022-05-04 15:55:18',	'2022-05-04 15:55:18');

DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE `users_roles` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_user_roles_role_id` (`role_id`),
  CONSTRAINT `FKh8ciramu9cc9q3qcqiv4ue8a6` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `FKhfh9dx7w3ubf1co1vdev94g3f` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_user_roles_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_user_roles_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES
(58,	2),
(59,	2),
(60,	2);

DROP TABLE IF EXISTS `user_product`;
CREATE TABLE `user_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `product_id` int(11) NOT NULL,
  `balance` decimal(10,0) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL,
  `product_number` varchar(10) NOT NULL DEFAULT '1',
  `termination_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_product_id` (`user_id`,`product_id`),
  UNIQUE KEY `product_number` (`product_number`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `user_product_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user_product` (`id`, `user_id`, `product_id`, `balance`, `status`, `product_number`, `termination_date`, `created_at`, `updated_at`) VALUES
(11,	58,	1,	1000000,	'ACTIVE',	'1284830368',	NULL,	'2022-05-04 10:57:30',	'2022-05-04 10:57:30'),
(12,	58,	2,	950000,	'ACTIVE',	'1284830367',	NULL,	'2022-05-04 15:55:11',	'2022-05-04 15:55:11'),
(13,	59,	1,	1050000,	'ACTIVE',	'1108260027',	NULL,	'2022-05-04 15:55:11',	'2022-05-04 15:55:11'),
(14,	60,	1,	950000,	'ACTIVE',	'1180934582',	NULL,	'2022-05-04 10:58:04',	'2022-05-04 10:58:04');

DROP TABLE IF EXISTS `verificationtoken`;
CREATE TABLE `verificationtoken` (
  `id` bigint(20) NOT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `token` text DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VERIFY_USER` (`user_id`),
  CONSTRAINT `FK_VERIFY_USER` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `verificationtoken` (`id`, `expiry_date`, `token`, `user_id`) VALUES
(45,	'2022-05-05 10:55:18',	'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI2MCIsInNjb3BlcyI6IlJPTEVfVVNFUixDVVNUT01FUl9SRUFEX1BSSVZJTEVHRSxVU0VSU1VNTUFSWURUT19XUklURV9QUklWSUxFR0UiLCJleHAiOjE2NTE3NDgxMTh9.jQbSLa74XC-h6YROeV40dfbt0-4CDYQPO_Ta4StXF1U',	60);

DROP TABLE IF EXISTS `votes`;
CREATE TABLE `votes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `poll_id` bigint(20) NOT NULL,
  `choice_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK8um9h2wxsdjrgx3rjjwvny676` (`poll_id`,`user_id`),
  KEY `fk_votes_user_id` (`user_id`),
  KEY `fk_votes_poll_id` (`poll_id`),
  KEY `fk_votes_choice_id` (`choice_id`),
  CONSTRAINT `FK7trt3uyihr4g13hva9d31puxg` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`),
  CONSTRAINT `FKli4uj3ic2vypf5pialchj925e` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKomskymhxde3qq9mcukyp1puio` FOREIGN KEY (`choice_id`) REFERENCES `choices` (`id`),
  CONSTRAINT `fk_votes_choice_id` FOREIGN KEY (`choice_id`) REFERENCES `choices` (`id`),
  CONSTRAINT `fk_votes_poll_id` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`),
  CONSTRAINT `fk_votes_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2022-05-04 18:35:52
